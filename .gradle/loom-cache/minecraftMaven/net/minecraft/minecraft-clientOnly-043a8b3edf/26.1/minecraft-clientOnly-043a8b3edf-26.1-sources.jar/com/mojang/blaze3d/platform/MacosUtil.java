package com.mojang.blaze3d.platform;

import ca.weblite.objc.Client;
import ca.weblite.objc.NSObject;
import com.sun.jna.Pointer;
import java.io.IOException;
import java.io.InputStream;
import java.util.Base64;
import java.util.Locale;
import java.util.Optional;
import net.minecraft.server.packs.resources.IoSupplier;
import org.lwjgl.glfw.GLFWNativeCocoa;

public class MacosUtil {
	public static final boolean IS_MACOS = System.getProperty("os.name").toLowerCase(Locale.ROOT).contains("mac");
	private static final int NS_RESIZABLE_WINDOW_MASK = 8;
	private static final int NS_FULL_SCREEN_WINDOW_MASK = 16384;

	public static void exitNativeFullscreen(final Window window) {
		getNsWindow(window).filter(MacosUtil::isInNativeFullscreen).ifPresent(MacosUtil::toggleNativeFullscreen);
	}

	public static void clearResizableBit(final Window window) {
		getNsWindow(window).ifPresent(nsWindow -> {
			long styleMask = getStyleMask(nsWindow);
			nsWindow.send("setStyleMask:", new Object[]{styleMask & -9L});
		});
	}

	private static Optional<NSObject> getNsWindow(final Window window) {
		long nsWindow = GLFWNativeCocoa.glfwGetCocoaWindow(window.handle());
		return nsWindow != 0L ? Optional.of(new NSObject(new Pointer(nsWindow))) : Optional.empty();
	}

	private static boolean isInNativeFullscreen(final NSObject nsWindow) {
		return (getStyleMask(nsWindow) & 16384L) != 0L;
	}

	private static long getStyleMask(final NSObject nsWindow) {
		return (Long)nsWindow.sendRaw("styleMask", new Object[0]);
	}

	private static void toggleNativeFullscreen(final NSObject nsWindow) {
		nsWindow.send("toggleFullScreen:", new Object[]{Pointer.NULL});
	}

	public static void loadIcon(final IoSupplier<InputStream> icon) throws IOException {
		try (InputStream iconStream = (InputStream)icon.get()) {
			String base64Icon = Base64.getEncoder().encodeToString(iconStream.readAllBytes());
			Client objc = Client.getInstance();
			Object data = objc.sendProxy("NSData", "alloc", new Object[0]).send("initWithBase64Encoding:", new Object[]{base64Icon});
			Object image = objc.sendProxy("NSImage", "alloc", new Object[0]).send("initWithData:", new Object[]{data});
			objc.sendProxy("NSApplication", "sharedApplication", new Object[0]).send("setApplicationIconImage:", new Object[]{image});
		}
	}
}
