package net.minecraft.data.worldgen;

import net.minecraft.data.worldgen.placement.AquaticPlacements;
import net.minecraft.data.worldgen.placement.CavePlacements;
import net.minecraft.data.worldgen.placement.MiscOverworldPlacements;
import net.minecraft.data.worldgen.placement.OrePlacements;
import net.minecraft.data.worldgen.placement.VegetationPlacements;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.level.biome.MobSpawnSettings;
import net.minecraft.world.level.biome.BiomeGenerationSettings.Builder;
import net.minecraft.world.level.levelgen.GenerationStep.Decoration;

public class BiomeDefaultFeatures {
	public static void addDefaultCarversAndLakes(final Builder builder) {
		builder.addCarver(Carvers.CAVE);
		builder.addCarver(Carvers.CAVE_EXTRA_UNDERGROUND);
		builder.addCarver(Carvers.CANYON);
		builder.addFeature(Decoration.LAKES, MiscOverworldPlacements.LAKE_LAVA_UNDERGROUND);
		builder.addFeature(Decoration.LAKES, MiscOverworldPlacements.LAKE_LAVA_SURFACE);
	}

	public static void addDefaultMonsterRoom(final Builder builder) {
		builder.addFeature(Decoration.UNDERGROUND_STRUCTURES, CavePlacements.MONSTER_ROOM);
		builder.addFeature(Decoration.UNDERGROUND_STRUCTURES, CavePlacements.MONSTER_ROOM_DEEP);
	}

	public static void addDefaultUndergroundVariety(final Builder builder) {
		builder.addFeature(Decoration.UNDERGROUND_ORES, OrePlacements.ORE_DIRT);
		builder.addFeature(Decoration.UNDERGROUND_ORES, OrePlacements.ORE_GRAVEL);
		builder.addFeature(Decoration.UNDERGROUND_ORES, OrePlacements.ORE_GRANITE_UPPER);
		builder.addFeature(Decoration.UNDERGROUND_ORES, OrePlacements.ORE_GRANITE_LOWER);
		builder.addFeature(Decoration.UNDERGROUND_ORES, OrePlacements.ORE_DIORITE_UPPER);
		builder.addFeature(Decoration.UNDERGROUND_ORES, OrePlacements.ORE_DIORITE_LOWER);
		builder.addFeature(Decoration.UNDERGROUND_ORES, OrePlacements.ORE_ANDESITE_UPPER);
		builder.addFeature(Decoration.UNDERGROUND_ORES, OrePlacements.ORE_ANDESITE_LOWER);
		builder.addFeature(Decoration.UNDERGROUND_ORES, OrePlacements.ORE_TUFF);
		builder.addFeature(Decoration.VEGETAL_DECORATION, CavePlacements.GLOW_LICHEN);
	}

	public static void addDripstone(final Builder builder) {
		builder.addFeature(Decoration.LOCAL_MODIFICATIONS, CavePlacements.LARGE_DRIPSTONE);
		builder.addFeature(Decoration.UNDERGROUND_DECORATION, CavePlacements.DRIPSTONE_CLUSTER);
		builder.addFeature(Decoration.UNDERGROUND_DECORATION, CavePlacements.POINTED_DRIPSTONE);
	}

	public static void addSculk(final Builder builder) {
		builder.addFeature(Decoration.UNDERGROUND_DECORATION, CavePlacements.SCULK_VEIN);
		builder.addFeature(Decoration.UNDERGROUND_DECORATION, CavePlacements.SCULK_PATCH_DEEP_DARK);
	}

	public static void addDefaultOres(final Builder builder) {
		addDefaultOres(builder, false);
	}

	public static void addDefaultOres(final Builder builder, final boolean largeCopperBlobs) {
		builder.addFeature(Decoration.UNDERGROUND_ORES, OrePlacements.ORE_COAL_UPPER);
		builder.addFeature(Decoration.UNDERGROUND_ORES, OrePlacements.ORE_COAL_LOWER);
		builder.addFeature(Decoration.UNDERGROUND_ORES, OrePlacements.ORE_IRON_UPPER);
		builder.addFeature(Decoration.UNDERGROUND_ORES, OrePlacements.ORE_IRON_MIDDLE);
		builder.addFeature(Decoration.UNDERGROUND_ORES, OrePlacements.ORE_IRON_SMALL);
		builder.addFeature(Decoration.UNDERGROUND_ORES, OrePlacements.ORE_GOLD);
		builder.addFeature(Decoration.UNDERGROUND_ORES, OrePlacements.ORE_GOLD_LOWER);
		builder.addFeature(Decoration.UNDERGROUND_ORES, OrePlacements.ORE_REDSTONE);
		builder.addFeature(Decoration.UNDERGROUND_ORES, OrePlacements.ORE_REDSTONE_LOWER);
		builder.addFeature(Decoration.UNDERGROUND_ORES, OrePlacements.ORE_DIAMOND);
		builder.addFeature(Decoration.UNDERGROUND_ORES, OrePlacements.ORE_DIAMOND_MEDIUM);
		builder.addFeature(Decoration.UNDERGROUND_ORES, OrePlacements.ORE_DIAMOND_LARGE);
		builder.addFeature(Decoration.UNDERGROUND_ORES, OrePlacements.ORE_DIAMOND_BURIED);
		builder.addFeature(Decoration.UNDERGROUND_ORES, OrePlacements.ORE_LAPIS);
		builder.addFeature(Decoration.UNDERGROUND_ORES, OrePlacements.ORE_LAPIS_BURIED);
		builder.addFeature(Decoration.UNDERGROUND_ORES, largeCopperBlobs ? OrePlacements.ORE_COPPER_LARGE : OrePlacements.ORE_COPPER);
		builder.addFeature(Decoration.UNDERGROUND_ORES, CavePlacements.UNDERWATER_MAGMA);
	}

	public static void addExtraGold(final Builder builder) {
		builder.addFeature(Decoration.UNDERGROUND_ORES, OrePlacements.ORE_GOLD_EXTRA);
	}

	public static void addExtraEmeralds(final Builder builder) {
		builder.addFeature(Decoration.UNDERGROUND_ORES, OrePlacements.ORE_EMERALD);
	}

	public static void addInfestedStone(final Builder builder) {
		builder.addFeature(Decoration.UNDERGROUND_DECORATION, OrePlacements.ORE_INFESTED);
	}

	public static void addDefaultSoftDisks(final Builder builder) {
		builder.addFeature(Decoration.UNDERGROUND_ORES, MiscOverworldPlacements.DISK_SAND);
		builder.addFeature(Decoration.UNDERGROUND_ORES, MiscOverworldPlacements.DISK_CLAY);
		builder.addFeature(Decoration.UNDERGROUND_ORES, MiscOverworldPlacements.DISK_GRAVEL);
	}

	public static void addSwampClayDisk(final Builder builder) {
		builder.addFeature(Decoration.UNDERGROUND_ORES, MiscOverworldPlacements.DISK_CLAY);
	}

	public static void addMangroveSwampDisks(final Builder builder) {
		builder.addFeature(Decoration.UNDERGROUND_ORES, MiscOverworldPlacements.DISK_GRASS);
		builder.addFeature(Decoration.UNDERGROUND_ORES, MiscOverworldPlacements.DISK_CLAY);
	}

	public static void addMossyStoneBlock(final Builder builder) {
		builder.addFeature(Decoration.LOCAL_MODIFICATIONS, MiscOverworldPlacements.FOREST_ROCK);
	}

	public static void addFerns(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_LARGE_FERN);
	}

	public static void addBushes(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_BUSH);
	}

	public static void addRareBerryBushes(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_BERRY_RARE);
	}

	public static void addCommonBerryBushes(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_BERRY_COMMON);
	}

	public static void addLightBambooVegetation(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.BAMBOO_LIGHT);
	}

	public static void addBambooVegetation(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.BAMBOO);
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.BAMBOO_VEGETATION);
	}

	public static void addTaigaTrees(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.TREES_TAIGA);
	}

	public static void addGroveTrees(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.TREES_GROVE);
	}

	public static void addWaterTrees(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.TREES_WATER);
	}

	public static void addBirchTrees(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.TREES_BIRCH);
	}

	public static void addOtherBirchTrees(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.TREES_BIRCH_AND_OAK_LEAF_LITTER);
	}

	public static void addTallBirchTrees(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.BIRCH_TALL);
	}

	public static void addBirchForestFlowers(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.WILDFLOWERS_BIRCH_FOREST);
	}

	public static void addSavannaTrees(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.TREES_SAVANNA);
	}

	public static void addShatteredSavannaTrees(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.TREES_WINDSWEPT_SAVANNA);
	}

	public static void addLushCavesVegetationFeatures(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, CavePlacements.LUSH_CAVES_CEILING_VEGETATION);
		builder.addFeature(Decoration.VEGETAL_DECORATION, CavePlacements.CAVE_VINES);
		builder.addFeature(Decoration.VEGETAL_DECORATION, CavePlacements.LUSH_CAVES_CLAY);
		builder.addFeature(Decoration.VEGETAL_DECORATION, CavePlacements.LUSH_CAVES_VEGETATION);
		builder.addFeature(Decoration.VEGETAL_DECORATION, CavePlacements.ROOTED_AZALEA_TREE);
		builder.addFeature(Decoration.VEGETAL_DECORATION, CavePlacements.SPORE_BLOSSOM);
		builder.addFeature(Decoration.VEGETAL_DECORATION, CavePlacements.CLASSIC_VINES);
	}

	public static void addSulfurCavesFeatures(final Builder builder) {
		builder.addFeature(Decoration.LAKES, CavePlacements.ROOTED_SULFUR_SPRING);
		builder.addFeature(Decoration.LAKES, MiscOverworldPlacements.SULFUR_POOL);
		builder.addFeature(Decoration.UNDERGROUND_DECORATION, CavePlacements.SULFUR_SPIKE_CLUSTER);
		builder.addFeature(Decoration.UNDERGROUND_DECORATION, CavePlacements.SULFUR_SPIKE);
	}

	public static void addLushCavesSpecialOres(final Builder builder) {
		builder.addFeature(Decoration.UNDERGROUND_ORES, OrePlacements.ORE_CLAY);
	}

	public static void addMountainTrees(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.TREES_WINDSWEPT_HILLS);
	}

	public static void addMountainForestTrees(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.TREES_WINDSWEPT_FOREST);
	}

	public static void addJungleTrees(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.TREES_JUNGLE);
	}

	public static void addSparseJungleTrees(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.TREES_SPARSE_JUNGLE);
	}

	public static void addBadlandsTrees(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.TREES_BADLANDS);
	}

	public static void addSnowyTrees(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.TREES_SNOWY);
	}

	public static void addJungleGrass(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_GRASS_JUNGLE);
	}

	public static void addSavannaGrass(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_TALL_GRASS);
	}

	public static void addShatteredSavannaGrass(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_GRASS_NORMAL);
	}

	public static void addSavannaExtraGrass(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_GRASS_SAVANNA);
	}

	public static void addBadlandGrass(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_GRASS_BADLANDS);
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_DRY_GRASS_BADLANDS);
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_DEAD_BUSH_BADLANDS);
	}

	public static void addForestFlowers(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.FOREST_FLOWERS);
	}

	public static void addForestGrass(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_GRASS_FOREST);
	}

	public static void addSwampVegetation(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.TREES_SWAMP);
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.FLOWER_SWAMP);
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_GRASS_NORMAL);
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_DEAD_BUSH);
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_WATERLILY);
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.BROWN_MUSHROOM_SWAMP);
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.RED_MUSHROOM_SWAMP);
	}

	public static void addMangroveSwampVegetation(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.TREES_MANGROVE);
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_GRASS_NORMAL);
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_DEAD_BUSH);
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_WATERLILY);
	}

	public static void addMushroomFieldVegetation(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.MUSHROOM_ISLAND_VEGETATION);
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.BROWN_MUSHROOM_TAIGA);
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.RED_MUSHROOM_TAIGA);
	}

	public static void addPlainVegetation(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.TREES_PLAINS);
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.FLOWER_PLAINS);
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_GRASS_PLAIN);
	}

	public static void addDesertVegetation(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_DRY_GRASS_DESERT);
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_DEAD_BUSH_2);
	}

	public static void addGiantTaigaVegetation(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_GRASS_TAIGA);
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_DEAD_BUSH);
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.BROWN_MUSHROOM_OLD_GROWTH);
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.RED_MUSHROOM_OLD_GROWTH);
	}

	public static void addDefaultFlowers(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.FLOWER_DEFAULT);
	}

	public static void addCherryGroveVegetation(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_GRASS_PLAIN);
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.FLOWER_CHERRY);
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.TREES_CHERRY);
	}

	public static void addMeadowVegetation(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_GRASS_MEADOW);
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.FLOWER_MEADOW);
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.TREES_MEADOW);
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.WILDFLOWERS_MEADOW);
	}

	public static void addWarmFlowers(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.FLOWER_WARM);
	}

	public static void addDefaultGrass(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_GRASS_BADLANDS);
	}

	public static void addTaigaGrass(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_GRASS_TAIGA_2);
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.BROWN_MUSHROOM_TAIGA);
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.RED_MUSHROOM_TAIGA);
	}

	public static void addPlainGrass(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_TALL_GRASS_2);
	}

	public static void addDefaultMushrooms(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.BROWN_MUSHROOM_NORMAL);
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.RED_MUSHROOM_NORMAL);
	}

	public static void addDefaultExtraVegetation(final Builder builder, final boolean shouldGenerateNearWaterVegetation) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_PUMPKIN);
		if (shouldGenerateNearWaterVegetation) {
			addNearWaterVegetation(builder);
		}
	}

	public static void addNearWaterVegetation(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_SUGAR_CANE);
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_FIREFLY_BUSH_NEAR_WATER);
	}

	public static void addLeafLitterPatch(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_LEAF_LITTER);
	}

	public static void addBadlandExtraVegetation(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_SUGAR_CANE_BADLANDS);
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_PUMPKIN);
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_CACTUS_DECORATED);
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_FIREFLY_BUSH_NEAR_WATER);
	}

	public static void addJungleMelons(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_MELON);
	}

	public static void addSparseJungleMelons(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_MELON_SPARSE);
	}

	public static void addJungleVines(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.VINES);
	}

	public static void addDesertExtraVegetation(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_SUGAR_CANE_DESERT);
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_PUMPKIN);
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_CACTUS_DESERT);
	}

	public static void addSwampExtraVegetation(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_SUGAR_CANE_SWAMP);
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_PUMPKIN);
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_FIREFLY_BUSH_SWAMP);
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_FIREFLY_BUSH_NEAR_WATER_SWAMP);
	}

	public static void addMangroveSwampExtraVegetation(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, AquaticPlacements.SEAGRASS_SWAMP);
		builder.addFeature(Decoration.VEGETAL_DECORATION, VegetationPlacements.PATCH_FIREFLY_BUSH_NEAR_WATER);
	}

	public static void addDesertExtraDecoration(final Builder builder) {
		builder.addFeature(Decoration.SURFACE_STRUCTURES, MiscOverworldPlacements.DESERT_WELL);
	}

	public static void addFossilDecoration(final Builder builder) {
		builder.addFeature(Decoration.UNDERGROUND_STRUCTURES, CavePlacements.FOSSIL_UPPER);
		builder.addFeature(Decoration.UNDERGROUND_STRUCTURES, CavePlacements.FOSSIL_LOWER);
	}

	public static void addColdOceanExtraVegetation(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, AquaticPlacements.KELP_COLD);
	}

	public static void addLukeWarmKelp(final Builder builder) {
		builder.addFeature(Decoration.VEGETAL_DECORATION, AquaticPlacements.KELP_WARM);
	}

	public static void addDefaultSprings(final Builder builder) {
		builder.addFeature(Decoration.FLUID_SPRINGS, MiscOverworldPlacements.SPRING_WATER);
		builder.addFeature(Decoration.FLUID_SPRINGS, MiscOverworldPlacements.SPRING_LAVA);
	}

	public static void addFrozenSprings(final Builder builder) {
		builder.addFeature(Decoration.FLUID_SPRINGS, MiscOverworldPlacements.SPRING_LAVA_FROZEN);
	}

	public static void addIcebergs(final Builder builder) {
		builder.addFeature(Decoration.LOCAL_MODIFICATIONS, MiscOverworldPlacements.ICEBERG_PACKED);
		builder.addFeature(Decoration.LOCAL_MODIFICATIONS, MiscOverworldPlacements.ICEBERG_BLUE);
	}

	public static void addBlueIce(final Builder builder) {
		builder.addFeature(Decoration.SURFACE_STRUCTURES, MiscOverworldPlacements.BLUE_ICE);
	}

	public static void addSurfaceFreezing(final Builder builder) {
		builder.addFeature(Decoration.TOP_LAYER_MODIFICATION, MiscOverworldPlacements.FREEZE_TOP_LAYER);
	}

	public static void addNetherDefaultOres(final Builder builder) {
		builder.addFeature(Decoration.UNDERGROUND_DECORATION, OrePlacements.ORE_GRAVEL_NETHER);
		builder.addFeature(Decoration.UNDERGROUND_DECORATION, OrePlacements.ORE_BLACKSTONE);
		builder.addFeature(Decoration.UNDERGROUND_DECORATION, OrePlacements.ORE_GOLD_NETHER);
		builder.addFeature(Decoration.UNDERGROUND_DECORATION, OrePlacements.ORE_QUARTZ_NETHER);
		addAncientDebris(builder);
	}

	public static void addAncientDebris(final Builder builder) {
		builder.addFeature(Decoration.UNDERGROUND_DECORATION, OrePlacements.ORE_ANCIENT_DEBRIS_LARGE);
		builder.addFeature(Decoration.UNDERGROUND_DECORATION, OrePlacements.ORE_ANCIENT_DEBRIS_SMALL);
	}

	public static void addDefaultCrystalFormations(final Builder builder) {
		builder.addFeature(Decoration.LOCAL_MODIFICATIONS, CavePlacements.AMETHYST_GEODE);
	}

	public static void farmAnimals(final MobSpawnSettings.Builder builder) {
		builder.addSpawn(MobCategory.CREATURE, 12, new MobSpawnSettings.SpawnerData(EntityTypes.SHEEP, 4, 4));
		builder.addSpawn(MobCategory.CREATURE, 10, new MobSpawnSettings.SpawnerData(EntityTypes.PIG, 4, 4));
		builder.addSpawn(MobCategory.CREATURE, 10, new MobSpawnSettings.SpawnerData(EntityTypes.CHICKEN, 4, 4));
		builder.addSpawn(MobCategory.CREATURE, 8, new MobSpawnSettings.SpawnerData(EntityTypes.COW, 4, 4));
	}

	public static void caveSpawns(final MobSpawnSettings.Builder builder) {
		builder.addSpawn(MobCategory.AMBIENT, 10, new MobSpawnSettings.SpawnerData(EntityTypes.BAT, 8, 8));
		builder.addSpawn(MobCategory.UNDERGROUND_WATER_CREATURE, 10, new MobSpawnSettings.SpawnerData(EntityTypes.GLOW_SQUID, 4, 6));
	}

	public static void commonSpawns(final MobSpawnSettings.Builder builder) {
		commonSpawns(builder, 100);
	}

	public static void commonSpawns(final MobSpawnSettings.Builder builder, final int skeletonWeight) {
		caveSpawns(builder);
		monsters(builder, 95, 5, 0, skeletonWeight, false);
	}

	public static void commonSpawnWithZombieHorse(final MobSpawnSettings.Builder builder) {
		caveSpawns(builder);
		monsters(builder, 90, 5, 5, 100, false);
	}

	public static void swampSpawns(final MobSpawnSettings.Builder builder, final int swampSkeletonWeight) {
		commonSpawns(builder, swampSkeletonWeight);
		builder.addSpawn(MobCategory.MONSTER, 1, new MobSpawnSettings.SpawnerData(EntityTypes.SLIME, 1, 1));
		builder.addSpawn(MobCategory.MONSTER, 30, new MobSpawnSettings.SpawnerData(EntityTypes.BOGGED, 4, 4));
		builder.addSpawn(MobCategory.CREATURE, 10, new MobSpawnSettings.SpawnerData(EntityTypes.FROG, 2, 5));
	}

	public static void oceanSpawns(
		final MobSpawnSettings.Builder builder, final int squidProbabilityWeight, final int squidMaxCount, final int codProbabilityWeight
	) {
		builder.addSpawn(MobCategory.WATER_CREATURE, squidProbabilityWeight, new MobSpawnSettings.SpawnerData(EntityTypes.SQUID, 1, squidMaxCount));
		builder.addSpawn(MobCategory.WATER_AMBIENT, codProbabilityWeight, new MobSpawnSettings.SpawnerData(EntityTypes.COD, 3, 6));
		commonSpawns(builder);
		builder.addSpawn(MobCategory.MONSTER, 5, new MobSpawnSettings.SpawnerData(EntityTypes.DROWNED, 1, 1));
	}

	public static void warmOceanSpawns(final MobSpawnSettings.Builder builder, final int squidProbabilityWeight, final int squidMinCount) {
		builder.addSpawn(MobCategory.WATER_CREATURE, squidProbabilityWeight, new MobSpawnSettings.SpawnerData(EntityTypes.SQUID, squidMinCount, 4));
		builder.addSpawn(MobCategory.WATER_AMBIENT, 25, new MobSpawnSettings.SpawnerData(EntityTypes.TROPICAL_FISH, 8, 8));
		builder.addSpawn(MobCategory.WATER_CREATURE, 2, new MobSpawnSettings.SpawnerData(EntityTypes.DOLPHIN, 1, 2));
		builder.addSpawn(MobCategory.MONSTER, 5, new MobSpawnSettings.SpawnerData(EntityTypes.DROWNED, 1, 1));
		commonSpawns(builder);
	}

	public static void plainsSpawns(final MobSpawnSettings.Builder builder) {
		farmAnimals(builder);
		builder.addSpawn(MobCategory.CREATURE, 5, new MobSpawnSettings.SpawnerData(EntityTypes.HORSE, 2, 6));
		builder.addSpawn(MobCategory.CREATURE, 1, new MobSpawnSettings.SpawnerData(EntityTypes.DONKEY, 1, 3));
		commonSpawnWithZombieHorse(builder);
	}

	public static void snowySpawns(final MobSpawnSettings.Builder builder, final boolean spawnZombieHorse) {
		builder.addSpawn(MobCategory.CREATURE, 10, new MobSpawnSettings.SpawnerData(EntityTypes.RABBIT, 2, 3));
		builder.addSpawn(MobCategory.CREATURE, 1, new MobSpawnSettings.SpawnerData(EntityTypes.POLAR_BEAR, 1, 2));
		caveSpawns(builder);
		monsters(builder, spawnZombieHorse ? 90 : 95, 5, spawnZombieHorse ? 5 : 0, 20, false);
		builder.addSpawn(MobCategory.MONSTER, 80, new MobSpawnSettings.SpawnerData(EntityTypes.STRAY, 4, 4));
	}

	public static void desertSpawns(final MobSpawnSettings.Builder builder) {
		builder.addSpawn(MobCategory.CREATURE, 12, new MobSpawnSettings.SpawnerData(EntityTypes.RABBIT, 2, 3));
		builder.addSpawn(MobCategory.CREATURE, 1, new MobSpawnSettings.SpawnerData(EntityTypes.CAMEL, 1, 1));
		caveSpawns(builder);
		monsters(builder, 19, 1, 0, 50, false);
		builder.addSpawn(MobCategory.MONSTER, 80, new MobSpawnSettings.SpawnerData(EntityTypes.HUSK, 4, 4));
		builder.addSpawn(MobCategory.MONSTER, 50, new MobSpawnSettings.SpawnerData(EntityTypes.PARCHED, 4, 4));
	}

	public static void dripstoneCavesSpawns(final MobSpawnSettings.Builder builder) {
		caveSpawns(builder);
		int zombieWeight = 95;
		monsters(builder, 95, 5, 0, 100, false);
		builder.addSpawn(MobCategory.MONSTER, 95, new MobSpawnSettings.SpawnerData(EntityTypes.DROWNED, 4, 4));
	}

	public static void monsters(
		final MobSpawnSettings.Builder builder,
		final int zombieWeight,
		final int zombieVillagerWeight,
		final int zombieHorseWeight,
		final int skeletonWeight,
		final boolean drownedZombies
	) {
		builder.addSpawn(MobCategory.MONSTER, 100, new MobSpawnSettings.SpawnerData(EntityTypes.SPIDER, 4, 4));
		builder.addSpawn(MobCategory.MONSTER, zombieWeight, new MobSpawnSettings.SpawnerData(drownedZombies ? EntityTypes.DROWNED : EntityTypes.ZOMBIE, 4, 4));
		builder.addSpawn(MobCategory.MONSTER, zombieVillagerWeight, new MobSpawnSettings.SpawnerData(EntityTypes.ZOMBIE_VILLAGER, 1, 1));
		if (zombieHorseWeight > 0) {
			builder.addSpawn(MobCategory.MONSTER, zombieHorseWeight, new MobSpawnSettings.SpawnerData(EntityTypes.ZOMBIE_HORSE, 1, 1));
		}

		builder.addSpawn(MobCategory.MONSTER, skeletonWeight, new MobSpawnSettings.SpawnerData(EntityTypes.SKELETON, 4, 4));
		builder.addSpawn(MobCategory.MONSTER, 100, new MobSpawnSettings.SpawnerData(EntityTypes.CREEPER, 4, 4));
		builder.addSpawn(MobCategory.MONSTER, 100, new MobSpawnSettings.SpawnerData(EntityTypes.SLIME, 4, 4));
		builder.addSpawn(MobCategory.MONSTER, 10, new MobSpawnSettings.SpawnerData(EntityTypes.ENDERMAN, 1, 4));
		builder.addSpawn(MobCategory.MONSTER, 5, new MobSpawnSettings.SpawnerData(EntityTypes.WITCH, 1, 1));
	}

	public static void mooshroomSpawns(final MobSpawnSettings.Builder builder) {
		builder.addSpawn(MobCategory.CREATURE, 8, new MobSpawnSettings.SpawnerData(EntityTypes.MOOSHROOM, 4, 8));
		caveSpawns(builder);
	}

	public static void baseJungleSpawns(final MobSpawnSettings.Builder builder) {
		farmAnimals(builder);
		builder.addSpawn(MobCategory.CREATURE, 10, new MobSpawnSettings.SpawnerData(EntityTypes.CHICKEN, 4, 4));
		commonSpawns(builder);
	}

	public static void endSpawns(final MobSpawnSettings.Builder builder) {
		builder.addSpawn(MobCategory.MONSTER, 10, new MobSpawnSettings.SpawnerData(EntityTypes.ENDERMAN, 4, 4));
	}
}
