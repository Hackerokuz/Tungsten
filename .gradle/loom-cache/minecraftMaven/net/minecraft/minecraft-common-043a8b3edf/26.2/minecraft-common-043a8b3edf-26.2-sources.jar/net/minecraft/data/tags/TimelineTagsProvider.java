package net.minecraft.data.tags;

import java.util.concurrent.CompletableFuture;
import net.minecraft.core.HolderLookup.Provider;
import net.minecraft.core.registries.Registries;
import net.minecraft.data.PackOutput;
import net.minecraft.tags.TimelineTags;
import net.minecraft.world.timeline.Timeline;
import net.minecraft.world.timeline.Timelines;

public class TimelineTagsProvider extends TagsProvider<Timeline> {
	public TimelineTagsProvider(final PackOutput output, final CompletableFuture<Provider> lookupProvider) {
		super(output, Registries.TIMELINE, lookupProvider);
	}

	@Override
	protected void addTags(final Provider registries) {
		this.tag(TimelineTags.UNIVERSAL).add(Timelines.VILLAGER_SCHEDULE);
		this.tag(TimelineTags.IN_OVERWORLD).addTag(TimelineTags.UNIVERSAL).add(Timelines.OVERWORLD_DAY, Timelines.MOON, Timelines.EARLY_GAME);
		this.tag(TimelineTags.IN_NETHER).addTag(TimelineTags.UNIVERSAL);
		this.tag(TimelineTags.IN_END).addTag(TimelineTags.UNIVERSAL);
	}
}
