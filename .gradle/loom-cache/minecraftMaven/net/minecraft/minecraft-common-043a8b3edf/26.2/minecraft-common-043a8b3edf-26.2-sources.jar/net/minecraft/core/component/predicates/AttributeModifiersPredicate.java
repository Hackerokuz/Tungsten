package net.minecraft.core.component.predicates;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.Optional;
import java.util.function.Predicate;
import net.minecraft.advancements.predicates.CollectionPredicate;
import net.minecraft.advancements.predicates.MinMaxBounds;
import net.minecraft.advancements.predicates.SingleComponentItemPredicate;
import net.minecraft.core.HolderSet;
import net.minecraft.core.RegistryCodecs;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier.Operation;
import net.minecraft.world.item.component.ItemAttributeModifiers;
import net.minecraft.world.item.component.ItemAttributeModifiers.Entry;

public record AttributeModifiersPredicate(Optional<CollectionPredicate<Entry, AttributeModifiersPredicate.EntryPredicate>> modifiers)
	implements SingleComponentItemPredicate<ItemAttributeModifiers> {
	public static final Codec<AttributeModifiersPredicate> CODEC = RecordCodecBuilder.create(
		i -> i.group(
				CollectionPredicate.<Entry, AttributeModifiersPredicate.EntryPredicate>codec(AttributeModifiersPredicate.EntryPredicate.CODEC)
					.optionalFieldOf("modifiers")
					.forGetter(AttributeModifiersPredicate::modifiers)
			)
			.apply(i, AttributeModifiersPredicate::new)
	);

	@Override
	public DataComponentType<ItemAttributeModifiers> componentType() {
		return DataComponents.ATTRIBUTE_MODIFIERS;
	}

	public boolean matches(final ItemAttributeModifiers value) {
		return !this.modifiers.isPresent() || this.modifiers.get().test(value.modifiers());
	}

	public record EntryPredicate(
		Optional<HolderSet<Attribute>> attribute,
		Optional<Identifier> id,
		MinMaxBounds.Doubles amount,
		Optional<Operation> operation,
		Optional<EquipmentSlotGroup> slot
	) implements Predicate<Entry> {
		public static final Codec<AttributeModifiersPredicate.EntryPredicate> CODEC = RecordCodecBuilder.create(
			i -> i.group(
					RegistryCodecs.homogeneousList(Registries.ATTRIBUTE).optionalFieldOf("attribute").forGetter(AttributeModifiersPredicate.EntryPredicate::attribute),
					Identifier.CODEC.optionalFieldOf("id").forGetter(AttributeModifiersPredicate.EntryPredicate::id),
					MinMaxBounds.Doubles.CODEC.optionalFieldOf("amount", MinMaxBounds.Doubles.ANY).forGetter(AttributeModifiersPredicate.EntryPredicate::amount),
					Operation.CODEC.optionalFieldOf("operation").forGetter(AttributeModifiersPredicate.EntryPredicate::operation),
					EquipmentSlotGroup.CODEC.optionalFieldOf("slot").forGetter(AttributeModifiersPredicate.EntryPredicate::slot)
				)
				.apply(i, AttributeModifiersPredicate.EntryPredicate::new)
		);

		public boolean test(final Entry value) {
			if (this.attribute.isPresent() && !this.attribute.get().contains(value.attribute())) {
				return false;
			} else if (this.id.isPresent() && !this.id.get().equals(value.modifier().id())) {
				return false;
			} else if (!this.amount.matches(value.modifier().amount())) {
				return false;
			} else {
				return this.operation.isPresent() && this.operation.get() != value.modifier().operation()
					? false
					: !this.slot.isPresent() || this.slot.get() == value.slot();
			}
		}
	}
}
